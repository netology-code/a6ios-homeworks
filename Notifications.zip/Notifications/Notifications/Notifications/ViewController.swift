//
//  ViewController.swift
//  Notifications
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import UserNotifications
import Photos

class ViewController: UIViewController {
    
    private var imageUrl: URL!
    
    // MARK: Public
    
    @IBAction func sendNotificationButtonPressed(_ sender: UIButton) {
        requestAuthorization()
    }
    
    // MARK: Private
    
    //1
    private func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
            success, error in
            if success {
                self.configureNotification()
                self.downloadImage {
                    success, url in
                    
                    if success {
                        self.createNotificaton(with: url!)
                    }
                }
            }
        }
    }
    //2
    private func configureNotification() {
        UNUserNotificationCenter.current().delegate = self
        //3
        let saveAction = UNNotificationAction(identifier: "save", title: "Save", options: [])
        let replyAction = UNTextInputNotificationAction(identifier: "reply", title: "Reply", options: [], textInputButtonTitle: "Reply", textInputPlaceholder: "Write your comment here")
        let seveAndReplyAction = UNTextInputNotificationAction(identifier: "save_reply", title: "Save and Reply", options: [], textInputButtonTitle: "Reply", textInputPlaceholder: "Write your comment here")
        //4
        let category = UNNotificationCategory(identifier: "humor", actions: [saveAction, replyAction, seveAndReplyAction], intentIdentifiers: [], options: [])
        UNUserNotificationCenter.current().setNotificationCategories([category])
    }
    //5
    private func createNotificaton(with url: URL) {
        //6
        let content = UNMutableNotificationContent()
        guard let imageAttachment = try? UNNotificationAttachment(identifier: "image", url: url, options: nil) else {
            return
        }
        
        content.title = "Notification"
        content.body = "Look at this funny cat in glasses"
        content.badge = 1
        content.attachments = [imageAttachment]
        content.categoryIdentifier = "humor"
        
        //7
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(identifier: "test", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    //8
    private func downloadImage(completion: @escaping(_ success: Bool, _ url: URL?) -> ()) {
        
        
        
        guard let url = URL(string: "https://cdn.pixabay.com/photo/2015/10/12/15/01/cat-984097_1280.jpg") else {
            return
        }
        
        let task = URLSession.shared.downloadTask(with: url) {
            downloadedUrl, _, error in
            
            if let error = error {
                print(error.localizedDescription)
                completion(false, nil)
            }
            
            guard let downloadedUrl = downloadedUrl else {
                print("No image received")
                completion(false, nil)
                return
            }
            
            //9
            let tmpUrl = FileManager.default.temporaryDirectory
            let fileName = "image1" + ".jpg"
            let fileNameCopy = "image2" + ".jpg"
            let fileEndpoint = tmpUrl.appendingPathComponent(fileName)
            let fileEndpointCopy = tmpUrl.appendingPathComponent(fileNameCopy)
            
            try? FileManager.default.moveItem(at: downloadedUrl, to: fileEndpoint)
            if FileManager.default.fileExists(atPath: fileEndpointCopy.path) {
                try? FileManager.default.removeItem(at: fileEndpointCopy)
            }
            try? FileManager.default.copyItem(at: fileEndpoint, to: fileEndpointCopy)
            
            self.imageUrl = fileEndpointCopy
            completion(true, fileEndpoint)
        }
        
        task.resume()
    }
}

// MARK: Delegate

extension ViewController: UNUserNotificationCenterDelegate {
    //10
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        completionHandler([.alert, .badge, .sound])
    }
    //11
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        if response.actionIdentifier == "humor" {
            
            switch response.actionIdentifier {
            case "save" :
                
                guard let image = UIImage(contentsOfFile: imageUrl.path) else {
                    return
                }
                //12
                UIImageWriteToSavedPhotosAlbum(image, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
                
            case "reply":
                //13
                if let response = response as? UNTextInputNotificationResponse {
                    print(response.userText)
                }
            case "save_reply":
                guard let image = UIImage(contentsOfFile: imageUrl.path) else {
                    return
                }
                UIImageWriteToSavedPhotosAlbum(image, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
                if let response = response as? UNTextInputNotificationResponse {
                    print(response.userText)
                }
            default:
                break
            }
        }
        completionHandler()
    }
    
    @objc private func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if error == nil {
            Alert.showBasic(title: "Saved!", message: "Image has been saved", vc: self)
            try? FileManager.default.removeItem(at: imageUrl)
        }
    }
}
