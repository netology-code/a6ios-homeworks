import UIKit
import AVKit
import Photos

class ViewController: UIViewController {
    
    private let videoURLString = "http://184.72.239.149/vod/smil:BigBuckBunny.smil/playlist.m3u8"
    
    // 17
    private lazy var videoRequestOptions: PHVideoRequestOptions = {
        let options = PHVideoRequestOptions()
        options.deliveryMode = .automatic
        options.isNetworkAccessAllowed = true
        options.version = .current
        
        return options
    }()
    
    // MARK: - Actions
    
    // 1
    @IBAction func playLibraryVideoTapHandler(sender: UIButton) {
        // 2
        let status = PHPhotoLibrary.authorizationStatus()
        
        switch status {
        case .authorized:
            // 3
            playVideo()
        case .notDetermined:
            // 4
            requestPhotoLibraryAccess()
        case .restricted:
            // 5
            print("access restricted")
        case .denied:
            // 6
            print("access denied")
        }
    }
    
    // 22
    @IBAction func playRemoteVideoTapHandler(sender: UIButton) {
        guard let url = URL(string: videoURLString) else {
            print("video url is unavailable")
            return
        }
        
        display(url: url)
     }
    
    // MARK: - Private
    
    private func requestPhotoLibraryAccess() {
        // 7
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized else {
                print("access denied by user")
                return
            }
            
            DispatchQueue.main.async {
                self.playVideo()
            }
        }
    }
    
    // 8
    private func playVideo() {
        // 9
        guard let videoAsset = loadVideoAsset() else {
            print("no videos available")
            return
        }
        
//        playVideoUsingPlayerItem(asset: videoAsset)
        playVideoUsingURL(asset: videoAsset)
    }
    
    // 10
    private func loadVideoAsset() -> PHAsset? {
        // 11
        let options = PHFetchOptions()
        // 12
        options.fetchLimit = 1
        // 13
        options.includeAssetSourceTypes = [.typeCloudShared, .typeUserLibrary, .typeiTunesSynced]
        // 14
        let videoAssets = PHAsset.fetchAssets(with: .video, options: options)
        
        guard videoAssets.count > 0 else {
            return nil
        }
        
        // 15
        return videoAssets.firstObject
    }
    
    // 16
    private func playVideoUsingPlayerItem(asset: PHAsset) {
        PHImageManager.default().requestPlayerItem(forVideo: asset, options: videoRequestOptions) { item, info in
            DispatchQueue.main.async {
                self.display(item: item)
            }
        }
    }
    
    // 20
    private func playVideoUsingURL(asset: PHAsset) {
        PHImageManager.default().requestAVAsset(forVideo: asset, options: videoRequestOptions) { avAsset, audioMix, info in
            guard let urlAsset = avAsset as? AVURLAsset else {
                print("video url is unavailable")
                return
            }
            
            DispatchQueue.main.async {
                self.display(url: urlAsset.url)
            }
        }
    }
    
    // 18
    private func display(item: AVPlayerItem?) {
        let player = AVPlayer(playerItem: item)
        presentPlayerViewController(with: player)
    }
    
    // 21
    private func display(url: URL) {
        let player = AVPlayer(url: url)
        presentPlayerViewController(with: player)
    }
    
    // 19
    private func presentPlayerViewController(with player: AVPlayer) {
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        
        present(playerViewController, animated: true) {
            player.play()
        }
    }
}
