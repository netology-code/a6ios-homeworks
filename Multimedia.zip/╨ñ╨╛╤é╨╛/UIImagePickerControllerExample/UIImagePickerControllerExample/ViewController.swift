import UIKit
import MobileCoreServices

class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    // MARK: - Actions
    
    @IBAction func showCamera(sender: UIButton) {
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            print("camera is unavailable")
            return
        }
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .camera
        imagePickerController.cameraDevice = .rear
        imagePickerController.delegate = self
        
        if let availableMediaTypesArray = UIImagePickerController.availableMediaTypes(for: .camera),
            availableMediaTypesArray.contains(kUTTypeImage as String) {
            imagePickerController.mediaTypes = [kUTTypeImage as String]
        }
        
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func showPhotoGallery(sender: UIButton) {
        guard UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) else {
            print("camera roll album is unavailable")
            return
        }
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .savedPhotosAlbum
        imagePickerController.delegate = self
        
        if let availableMediaTypesArray = UIImagePickerController.availableMediaTypes(for: .savedPhotosAlbum),
            availableMediaTypesArray.contains(kUTTypeImage as String) {
            imagePickerController.mediaTypes = [kUTTypeImage as String]
        }
        
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    @objc
    func image(_ image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            print("image saving failed:\(error.localizedDescription)")
            return
        }
        
        print("image saved to album!")
    }
}

extension ViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        defer { self.dismiss(animated: true, completion: nil) }
        
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            print("no image available")
            return
        }
        
        // using the image
        
        DispatchQueue.main.async {
            self.imageView.image = image
        }
        
        if picker.sourceType == .camera {
            UIImageWriteToSavedPhotosAlbum(image, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}
