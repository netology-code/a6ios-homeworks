//
//  ViewController.swift
//  AudioMix
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import AVFoundation
import AudioToolbox

class ViewController: UIViewController {
    @IBOutlet weak var playbutton: UIButton!
    @IBOutlet weak var mainTrackLabel: UILabel!
    @IBOutlet weak var soundLabel: UILabel!
    //1
    private var audioPlayer: AVAudioPlayer!
    //8
    private let systemSounds: [String: SystemSoundID] = ["SMSReceived": 1003, "CalendarAlert": 1005, "MailReceived": 1000, "LowPower": 1006]
    private var counter = 0
    
    //2
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpAudioPlayer()
    }
    //7
    @IBAction func playButtonPressed(_ sender: UIButton) {
        
        if audioPlayer.isPlaying {
            audioPlayer.stop()
            playbutton.setImage(#imageLiteral(resourceName: "play"), for: .normal)
            mainTrackLabel.text = "Not Playing"
            
            
        } else {
            audioPlayer.play()
            playbutton.setImage(#imageLiteral(resourceName: "stop"), for: .normal)
            mainTrackLabel.text = "Playing - Jazz"
        }
    }
    //9
    @IBAction func playSystemSoundButtonPressed(_ sender: UIButton) {
        let currentSoundID = Array(systemSounds.values)[counter]
        let currentSoundName = Array(systemSounds.keys)[counter]
        AudioServicesPlaySystemSound(currentSoundID)
        soundLabel.text = currentSoundName
        
        if counter == systemSounds.count-1 {
            counter = 0
        } else {
            counter += 1
        }
    }
    //10
    @IBAction func playCustomSoundButtonPressed(_ sender: UIButton) {
        //11
        guard let soundURL = Bundle.main.url(forResource: "Cat", withExtension: "wav") else {
            return
        }
        //12
        var soundID: SystemSoundID = 0
        //13
        AudioServicesCreateSystemSoundID(soundURL as CFURL, &soundID)
        //14
        AudioServicesAddSystemSoundCompletion(soundID, nil, nil, {
            soundID, _ in
            //15
            AudioServicesDisposeSystemSoundID(soundID)
            
        }, nil)
        //16
        AudioServicesPlaySystemSound(soundID)
        //17
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        soundLabel.text = "Cat"
    }
    
    //3
    private func setUpAudioPlayer() {
        guard let musicUrl = Bundle.main.url(forResource: "Jazz", withExtension: "mp3") else {
            return
        }
        //4
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: musicUrl)
            setUpAudioSession()
        } catch {
            //can't load file
        }
    }
    //5
    private func setUpAudioSession() {
        //6
        let audioSession = AVAudioSession.sharedInstance()
        //6
        do {
            try audioSession.setCategory(AVAudioSessionCategoryPlayback)
        } catch {
            // can't start audio session
        }
    }
}

