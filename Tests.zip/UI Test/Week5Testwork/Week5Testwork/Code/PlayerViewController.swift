//
//  PlayerViewController.swift
//  Week5Testwork
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class PlayerViewController: UIViewController {
    
    struct Constants {
        static let positionTypes = ["Defender", "Goalkeeper", "Midfield", "Forward"]
        static let clubs = ["Real Madrid", "FC Barcelona", "Manchester United", "Bayern Munich", "Milan", "Chelsea", "Arsenal", "Atlético Madrid", "Valencia", "Celta"]
    }
    
    private enum PickerViewDataSource {
        case position, club
    }
    
    @IBOutlet private weak var playerLocationSegmentedControl: UISegmentedControl!
    @IBOutlet private weak var playerImageView: UIImageView!
    @IBOutlet private weak var playerNumberTextField: UITextField!
    @IBOutlet private weak var playerNameTextField: UITextField!
    @IBOutlet private weak var playerNationalityTextField: UITextField!
    @IBOutlet private weak var playerAgeTextField: UITextField!
    @IBOutlet private weak var playerPositionSelectButton: UIButton!
    @IBOutlet private weak var playerClubSelectButton: UIButton!
    @IBOutlet private weak var viewWithPickerView: UIView!
    @IBOutlet private weak var pickerView: UIPickerView!
    @IBOutlet weak var saveButton: UIButton!
    
    var dataManager: CoreDataManager!
    var playerToEdit: Player!
    private var imagePickerController = UIImagePickerController()
    private var selectedImage = #imageLiteral(resourceName: "avatar")
    private var selectedPosition = ""
    private var selectedClub = ""
    private var pickerViewDataSource: PickerViewDataSource!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewWithPickerView.isHidden = true
        pickerView.delegate = self
        pickerView.dataSource = self
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        playerAgeTextField.delegate = self
        playerNameTextField.delegate = self
        playerNumberTextField.delegate = self
        playerNationalityTextField.delegate = self
        playerToEditCheckAndLoadData()
        disableSaveButton()
    }
    
    // MARK: Public
    
    @IBAction func uploadImageButtonPressed(_ sender: UIButton) {
        present(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func clubSelectButtonPressed(_ sender: UIButton) {
        pickerViewDataSource = .club
        pickerView.reloadAllComponents()
        viewWithPickerView.isHidden = false
    }
    
    @IBAction func positionSelectButtonPressed(_ sender: UIButton) {
        pickerViewDataSource = .position
        pickerView.reloadAllComponents()
        viewWithPickerView.isHidden = false
    }
    
    @IBAction func saveButtonPressed(_ sender: UIButton) {
        let context = dataManager.getContext()
        if playerToEdit != nil {
            fillPlayerData(player: playerToEdit)
        } else {
            let newPlayer = dataManager.createObject(from: Player.self)
            fillPlayerData(player: newPlayer)
        }
        
        dataManager.save(context: context)
        navigationController?.popViewController(animated: true)
    }
    
    // MARK: Private
    
    private func fetchClub(withName name: String) -> Club {
        let predicate = NSPredicate(format: "name LIKE '\(name)'")
        let club = dataManager.fetchData(for: Club.self, predicate: predicate).first!
        return club
    }
    
    private func playerToEditCheckAndLoadData() {
        if playerToEdit != nil {
            playerImageView.image = playerToEdit.image as? UIImage
            selectedImage = playerToEdit.image as! UIImage
            playerAgeTextField.text = String(playerToEdit.age)
            playerNameTextField.text = playerToEdit.name
            playerNumberTextField.text = String(playerToEdit.number)
            playerNationalityTextField.text = playerToEdit.nationality
            playerClubSelectButton.setTitle(playerToEdit.club?.name, for: .normal)
            playerPositionSelectButton.setTitle(playerToEdit.position, for: .normal)
            selectedClub = (playerToEdit.club?.name)!
            selectedPosition = playerToEdit.position!
        }
    }
    
    private func fillPlayerData(player: Player) {
        guard let number = playerNumberTextField.text,
            let age = playerAgeTextField.text,
            let name = playerNameTextField.text,
            let nationality = playerNationalityTextField.text else {
            return
        }
        
        player.age = Int16(age)!
        player.number = Int16(number)!
        player.name = name
        player.nationality = nationality
        player.image = selectedImage
        player.position = selectedPosition
        
        if player.club?.name != selectedClub {
            player.club = fetchClub(withName: selectedClub)
        }
        
        switch playerLocationSegmentedControl.selectedSegmentIndex {
        case 0:
            player.inPlay = true
        case 1:
            player.inPlay = false
        default:
            break
        }
    }
    
    private func enableSaveButton() {
        guard let name = playerNameTextField.text, let age = playerAgeTextField.text, let number = playerAgeTextField.text else {
            return
        }
        
        if !name.isEmpty && !age.isEmpty && !number.isEmpty && !selectedPosition.isEmpty && !selectedClub.isEmpty {
            saveButton.isEnabled = true
            saveButton.alpha = 1
        }
    }
    
    private func disableSaveButton(){
        saveButton.isEnabled = false
        saveButton.alpha = 0.5
    }
    
}

// MARK: Extensions

extension PlayerViewController: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerViewDataSource == .position {
            playerPositionSelectButton.setTitle(Constants.positionTypes[row], for: .normal)
            selectedPosition = Constants.positionTypes[row]
        } else {
            playerClubSelectButton.setTitle(Constants.clubs[row], for: .normal)
            selectedClub = Constants.clubs[row]
        }
        
        viewWithPickerView.isHidden = true
        enableSaveButton()
    }
}

extension PlayerViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerViewDataSource == .position {
            return Constants.positionTypes.count
        } else {
            return Constants.clubs.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerViewDataSource == .position {
            return Constants.positionTypes[row]
        } else {
            return Constants.clubs[row]
        }
    }
}

extension PlayerViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            return
        }
        selectedImage = image
        playerImageView.image = selectedImage
        
        defer {
            imagePickerController.dismiss(animated: true, completion: nil)
        }
    }
}

extension PlayerViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
}
