//
//  ViewController.swift
//  Week5Testwork
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import CoreData

class MainViewController: UIViewController {
    
    @IBOutlet private weak var playerTableView: UITableView!
    @IBOutlet private weak var playerSortSegmentedControl: UISegmentedControl!
    
    var dataManager: CoreDataManager!
    var fetchedResultController: NSFetchedResultsController<Player>!
    private var selectedPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [])
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        #if TEST
        fetchData()
        
        if (fetchedResultController.fetchedObjects?.isEmpty)! {
            fillDataModel()
        }
        
        #endif
        
        //fillDataModel()
        playerTableView.delegate = self
        playerTableView.dataSource = self
        fetchData()
        
        //accessibility
        playerTableView.accessibilityIdentifier = "playerTableView"
    }
    
    // MARK: Public
    
    @IBAction private func addPlayerButtonPressed(_ sender: UIBarButtonItem) {
        let playerViewController = PlayerViewController()
        playerViewController.dataManager = dataManager
        navigationController?.pushViewController(playerViewController, animated: true)
    }
    
    @IBAction func itemLocationSegmentedControlPressed(_ sender: UISegmentedControl) {
        let predicate = makePlayerSortCompoundPredicate(predicate: selectedPredicate)
        fetchData(predicate: predicate)
        playerTableView.reloadData()
    }
    
    @IBAction func searchButtonPressed(_ sender: UIBarButtonItem) {
        
        let searchViewController = SearchViewController()
        searchViewController.delegate = self
        searchViewController.modalTransitionStyle = .crossDissolve
        searchViewController.modalPresentationStyle = .overCurrentContext
        present(searchViewController, animated: true, completion: nil)
    }
    
    // MARK: Private
    
    private func fetchData(predicate: NSCompoundPredicate? = nil) {
        fetchedResultController = dataManager.fetchDataWithController(for: Player.self, sectionNameKeyPath: "position", predicate: predicate)
        fetchedResultController.delegate = self
        fetchObjectCheck()
    }
    
    private func fetchObjectCheck() {
        guard let fetchResult = fetchedResultController.fetchedObjects else {
            return
        }
        if fetchResult.count > 0 {
            playerTableView.isHidden = false
        } else {
            playerTableView.isHidden = true
        }
    }
    
    private func makePlayerSortCompoundPredicate(predicate: NSCompoundPredicate) -> NSCompoundPredicate {
        
        switch playerSortSegmentedControl.selectedSegmentIndex {
        case 0:
            return predicate
        case 1:
            let inPlayPredicate = NSPredicate(format: "inPlay == YES")
            return NSCompoundPredicate(andPredicateWithSubpredicates: [predicate, inPlayPredicate])
        case 2:
            let notInPlayPredicate = NSPredicate(format: "inPlay == NO")
            return NSCompoundPredicate(andPredicateWithSubpredicates: [predicate, notInPlayPredicate])
        default:
            break
        }
        return predicate
    }
}

// MARK: Extensions

extension MainViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let player = self.fetchedResultController.object(at: indexPath)
        let context = dataManager.getContext()
        
        let deleteAction = UITableViewRowAction(style: .destructive, title: "DELETE") {
            _, indexPath in
            
            self.dataManager.delete(object: player)
            
        }
        
        let editAction = UITableViewRowAction(style: .normal, title: "EDIT") {
            _, idexPath in
            
            let playerViewController = PlayerViewController()
            playerViewController.dataManager = self.dataManager
            playerViewController.playerToEdit = player
            self.navigationController?.pushViewController(playerViewController, animated: true)
        }
        
        var changePlayerLocation: UITableViewRowAction!
        
        if player.inPlay == true {
            let action = UITableViewRowAction(style: .normal, title: "TO BENCH") {
                _, indexPath in
                player.inPlay = false
                self.dataManager.save(context: context)
            }
            changePlayerLocation = action
        } else {
            let action = UITableViewRowAction(style: .normal, title: "TO PLAY") {
                _, indexPath in
                player.inPlay = true
                self.dataManager.save(context: context)
            }
            changePlayerLocation = action
        }
        
        deleteAction.backgroundColor = UIColor.red
        editAction.backgroundColor = UIColor.orange
        changePlayerLocation.backgroundColor = UIColor.purple
        
        return [deleteAction, editAction, changePlayerLocation]
    }
    
}

extension MainViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let sections = fetchedResultController.sections else {
            return 0
        }
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        guard let sections = fetchedResultController.sections else {
            return nil
        }
        return sections[section].name
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sections = fetchedResultController.sections else {
            return 0
        }
        return sections[section].numberOfObjects
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlayerTableViewCell", for: indexPath)
        if let cell = cell as? PlayerTableViewCell {
            let player = fetchedResultController.object(at: indexPath)
            cell.configureCell(with: player)
        }
        return cell
    }
}

extension MainViewController: NSFetchedResultsControllerDelegate {
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        playerTableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        
        switch type {
        case .insert:
            playerTableView.insertSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .fade)
        case .delete:
            playerTableView.deleteSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .fade)
        default:
            return
        }
        
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            if let indexPath = newIndexPath {
                playerTableView.insertRows(at: [indexPath], with: .fade)
                fetchObjectCheck()
            }
            
        case .delete:
            if let indexPath = indexPath {
                playerTableView.deleteRows(at: [indexPath], with: .fade)
                fetchObjectCheck()
            }
            
        case .update:
            if let indexPath = indexPath {
                //  playerTableView.reloadRows(at: [indexPath], with: .none)
                let cell = playerTableView.cellForRow(at: indexPath) as! PlayerTableViewCell
                let player = fetchedResultController.object(at: indexPath as IndexPath)
                cell.configureCell(with: player)
            }
            
        case .move:
            if let indexPath = indexPath {
                playerTableView.deleteRows(at: [indexPath], with: .fade)
            }
            if let indexPath = newIndexPath {
                playerTableView.insertRows(at: [indexPath], with: .fade)
            }
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        playerTableView.endUpdates()
    }
}

extension MainViewController: SearchDelegate {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate) {
        fetchData(predicate: makePlayerSortCompoundPredicate(predicate: predicate))
        selectedPredicate = predicate
        playerTableView.reloadData()
    }
}
