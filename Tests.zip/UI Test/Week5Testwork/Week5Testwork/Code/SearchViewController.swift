//
//  SearchViewController.swift
// Week5Testwork
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

protocol SearchDelegate: class {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate)
}

class SearchViewController: UIViewController {
    
    private enum PickerViewDataSource {
        case position, club
    }
    
    @IBOutlet private weak var bgView: UIView!
    @IBOutlet private weak var playerNameTextField: UITextField!
    @IBOutlet private weak var playerAgeTextField: UITextField!
    @IBOutlet private weak var ageSegmentedControl: UISegmentedControl!
    @IBOutlet private weak var positionSelectButton: UIButton!
    @IBOutlet private weak var clubSelectButton: UIButton!
    @IBOutlet private weak var viewWithPickerView: UIView!
    @IBOutlet private weak var pickerView: UIPickerView!
    
    weak var delegate: SearchDelegate?
    private var selectedPosition = ""
    private var selectedClub = ""
    private var pickerViewDataSource: PickerViewDataSource!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewWithPickerView.isHidden = true
        pickerView.delegate = self
        pickerView.dataSource = self
        playerNameTextField.delegate = self
        playerAgeTextField.delegate = self
        let closeTap = UITapGestureRecognizer(target: self, action: #selector(SearchViewController.closeTapGesture(_:)))
        bgView.addGestureRecognizer(closeTap)
    }
    
    // MARK: Public
    
    @IBAction func positionSelectButtonPressed(_ sender: UIButton) {
        pickerViewDataSource = .position
        pickerView.reloadAllComponents()
        viewWithPickerView.isHidden = false
    }
    
    @IBAction func clubSelectButtonPressed(_ sender: UIButton) {
        pickerViewDataSource = .club
        pickerView.reloadAllComponents()
        viewWithPickerView.isHidden = false
    }
    
    @IBAction func startSearchButtonPressed(_ sender: UIButton) {
        
        let compoundPredicate = makeCompoundPredicate(name: playerNameTextField.text!, club: selectedClub, age: playerAgeTextField.text!, position: selectedPosition)
        delegate?.viewController(self, didPassedData: compoundPredicate)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func resetButtonPressed(_ sender: UIButton) {
        delegate?.viewController(self, didPassedData: NSCompoundPredicate(andPredicateWithSubpredicates: []))
        
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: Private
    
    private func makeCompoundPredicate(name: String, club: String, age: String, position: String) -> NSCompoundPredicate {
        
        var predicates = [NSPredicate]()
        
        if !name.isEmpty {
            let namePredicate = NSPredicate(format: "name CONTAINS[cd] '\(name)'")
            predicates.append(namePredicate)
        }
        
        if !club.isEmpty {
            let clubPredicate = NSPredicate(format: "club.name LIKE '\(club)'")
            predicates.append(clubPredicate)
        }
        
        if !position.isEmpty {
            let positionPredicate = NSPredicate(format: "position LIKE '\(position)'")
            predicates.append(positionPredicate)
        }
        
        if !age.isEmpty {
            let selectedSegmentControl = ageSearchCondition(index: ageSegmentedControl.selectedSegmentIndex)
            let agePredicate = NSPredicate(format: "age \(selectedSegmentControl) \(age)")
            predicates.append(agePredicate)
        }
        
        return NSCompoundPredicate(andPredicateWithSubpredicates: predicates)
    }
    
    private func ageSearchCondition(index: Int) -> String {
        var condition: String!
        
        switch index {
        case 0: condition = ">="
        case 1: condition = "="
        case 2: condition = "<="
        default: break
        }
        return condition
    }
    
    @objc private func closeTapGesture (_ recognizer: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
}

// MARK: Extensions

extension SearchViewController: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerViewDataSource == .position {
            positionSelectButton.setTitle(PlayerViewController.Constants.positionTypes[row], for: .normal)
            selectedPosition = PlayerViewController.Constants.positionTypes[row]
        } else {
            clubSelectButton.setTitle(PlayerViewController.Constants.clubs[row], for: .normal)
            selectedClub = PlayerViewController.Constants.clubs[row]
        }
        
        viewWithPickerView.isHidden = true
    }
}

extension SearchViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerViewDataSource == .position {
            return PlayerViewController.Constants.positionTypes.count
        } else {
            return PlayerViewController.Constants.clubs.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerViewDataSource == .position {
            return PlayerViewController.Constants.positionTypes[row]
        } else {
            return PlayerViewController.Constants.clubs[row]
        }
    }
}

extension SearchViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
}
