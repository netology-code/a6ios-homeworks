//
//  ItemTableViewCell.swift
//   Week5Testwork
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class PlayerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var playerImageView: UIImageView!
    @IBOutlet weak var playerNameLabel: UILabel!
    @IBOutlet weak var playerTeamLabel: UILabel!
    @IBOutlet weak var playerNationalityLabel: UILabel!
    @IBOutlet weak var playerPositionLabel: UILabel!
    @IBOutlet weak var playerAgeLabel: UILabel!
    @IBOutlet weak var playerNumberLabel: UILabel!
    @IBOutlet weak var playerCellView: UIView!
    @IBOutlet weak var inPlayStatusLabel: UILabel!
    
    func configureCell(with player: Player) {
        playerImageView.image = player.image as? UIImage
        playerNameLabel.text = player.name
        playerTeamLabel.text = player.club?.name
        playerNationalityLabel.text = player.nationality
        playerPositionLabel.text = player.position
        playerAgeLabel.text = String(player.age)
        playerNumberLabel.text = String(player.number)
        
        if player.inPlay {
            inPlayStatusLabel.text = "In Play"
            inPlayStatusLabel.textColor = #colorLiteral(red: 0.5843137503, green: 0.8235294223, blue: 0.4196078479, alpha: 1)
        } else {
            inPlayStatusLabel.text = "Bench"
            inPlayStatusLabel.textColor = #colorLiteral(red: 0.9411764741, green: 0.4980392158, blue: 0.3529411852, alpha: 1)
        }
    }
}
