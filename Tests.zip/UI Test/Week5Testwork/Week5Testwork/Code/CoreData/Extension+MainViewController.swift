//
//  ModelData.swift
//   Week5Testwork
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

extension MainViewController {
    
    func fillDataModel() {
        
        let context = dataManager.getContext()
        
        //Clubs
        let manchester = createClub(name: "Manchester United")
        let barcelona = createClub(name: "FC Barcelona")
        let chelsea = createClub(name: "Chelsea")
        let milan = createClub(name: "Milan")
        let real = createClub(name: "Real Madrid")
        let arsenal = createClub(name: "Arsenal")
        let atletico = createClub(name: "Atlético Madrid")
        let bayer = createClub(name: "Bayern Munich")
        let valencia = createClub(name: "Valencia")
        let celta = createClub(name: "Celta")
        
        //Players
        let _ = createPlayer(name: "David de Gea", nationality: "Spain", image: #imageLiteral(resourceName: "David de Gea"), position: "Goalkeeper", number: 1, club: manchester, age: 27)
        let _ = createPlayer(name: "Kepa Arrizabalaga", nationality: "Spain", image: #imageLiteral(resourceName: "Kepa"), position: "Goalkeeper", number: 13, club: chelsea, age: 23)
        let _ = createPlayer(name: "Pepe Reina", nationality: "Spain", image: #imageLiteral(resourceName: "pepe"), position: "Goalkeeper", number: 23, club: milan, age: 35)
        let _ = createPlayer(name: "Dani Carvajal", nationality: "Spain", image: #imageLiteral(resourceName: "Dani Carvajal"), position: "Defender", number: 2, club: real, age: 26)
        let _ = createPlayer(name: "Nacho", nationality: "Spain", image: #imageLiteral(resourceName: "Nacho"), position: "Defender", number: 4, club: real, age: 28)
        let _ = createPlayer(name: "Álvaro Odriozola", nationality: "Spain", image: #imageLiteral(resourceName: "Odriozola"), position: "Defender", number: 12, club: real, age: 22)
        let _ = createPlayer(name: "César Azpilicueta", nationality: "Spain", image: #imageLiteral(resourceName: "Azpilicueta"), position: "Defender", number: 14, club: chelsea, age: 26)
        let _ = createPlayer(name: "Sergio Ramos", nationality: "Spain", image: #imageLiteral(resourceName: "Sergio Ramos"), position: "Defender", number: 15, club: real, age: 32)
        let _ = createPlayer(name: "Nacho Monreal", nationality: "Spain", image: #imageLiteral(resourceName: "Nacho Monreal"), position: "Defender", number: 16, club: arsenal, age: 32)
        let _ = createPlayer(name: "Jordi Alba", nationality: "Spain", image: #imageLiteral(resourceName: "Jordi Alba"), position: "Defender", number: 18, club: barcelona, age: 29)
        let _ = createPlayer(name: "Sergio Busquets", nationality: "Spain", image: #imageLiteral(resourceName: "Busquets"), position: "Midfield", number: 5, club: barcelona, age: 30)
        let _ = createPlayer(name: "Saúl", nationality: "Spain", image: #imageLiteral(resourceName: "Saul"), position: "Midfield", number: 7, club: atletico, age: 23)
        let _ = createPlayer(name: "Koke", nationality: "Spain", image: #imageLiteral(resourceName: "Koke"), position: "Midfield", number: 8, club: atletico, age: 26)
        let _ = createPlayer(name: "Thiago", nationality: "Spain", image: #imageLiteral(resourceName: "Thiago"), position: "Midfield", number: 10, club: bayer, age: 27)
        let _ = createPlayer(name: "Lucas Vázquez", nationality: "Spain", image: #imageLiteral(resourceName: "Lucas Vázquez"), position: "Midfield", number: 11, club: real, age: 27)
        let _ = createPlayer(name: "Marco Asensio", nationality: "Spain", image: #imageLiteral(resourceName: "Marco Asensio"), position: "Midfield", number: 20, club: real, age: 22)
        let _ = createPlayer(name: "Isco", nationality: "Spain", image: #imageLiteral(resourceName: "Isco"), position: "Midfield", number: 22, club: real, age: 26)
        let _ = createPlayer(name: "Rodrigo", nationality: "Spain", image: #imageLiteral(resourceName: "Rodrigo"), position: "Forward", number: 9, club: valencia, age: 27)
        let _ = createPlayer(name: "Iago Aspas", nationality: "Spain", image: #imageLiteral(resourceName: "Iago Aspas"), position: "Forward", number: 17, club: celta, age: 31)
        let _ = createPlayer(name: "Diego Costa", nationality: "Spain", image: #imageLiteral(resourceName: "Diego Costa"), position: "Forward", number: 19, club: atletico, age: 29)
        
        dataManager.save(context: context)
    }
    
    private func createClub(name: String) -> Club {
        let club = dataManager.createObject(from: Club.self)
        club.name = name
        return club
    }
    
    private func createPlayer(name: String, nationality: String, image: UIImage, position: String, number: Int16, club: Club, age: Int16) -> Player {
        let player = dataManager.createObject(from: Player.self)
        player.name = name
        player.nationality = nationality
        player.image = image
        player.position = position
        player.number = number
        player.club = club
        player.age = age
        return player
    }
}
