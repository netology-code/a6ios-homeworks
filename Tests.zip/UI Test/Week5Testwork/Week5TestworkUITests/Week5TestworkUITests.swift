//
//  Week5TestworkUITests.swift
//  Week5TestworkUITests
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import XCTest

class Week5TestworkUITests: XCTestCase {
    //1
    var app: XCUIApplication!
    
    //2
    override func setUp() {
        super.setUp()
        //3
        continueAfterFailure = false
        app =  XCUIApplication()
    }
    //4
    override func tearDown() {
        app = nil
        super.tearDown()
    }
    //5
    func testToPlayToBench() {
        app.launch()
        
        //6
        let table = app.tables["playerTableView"]
        let cells = table.cells.containing(.cell, identifier: "PlayerTableViewCell").allElementsBoundByIndex

        //7
        for i in 0...2 {
            //8
            cells[i].swipeLeft()
            //9
            app.buttons["TO PLAY"].tap()
            cells[i].swipeLeft()
            app.buttons["TO BENCH"].tap()
        }
    }
    //10
    func testAddPlayer() {
        app.launch()
        
        app.navigationBars["Team Manager"].buttons["Add"].tap()
        
        //11
        app.textFields["Name"].tap()
        //12
        app/*@START_MENU_TOKEN@*/.buttons["shift"]/*[[".keyboards.buttons[\"shift\"]",".buttons[\"shift\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        for i in "User" {
            app.keys["\(i)"].tap()
        }
        app.buttons["Return"].tap()
        
        app.textFields["Nationality"].tap()
        app/*@START_MENU_TOKEN@*/.buttons["shift"]/*[[".keyboards.buttons[\"shift\"]",".buttons[\"shift\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        for i in "Nationality" {
            app.keys["\(i)"].tap()
        }
        app.buttons["Return"].tap()
        
        app.textFields["Age"].tap()
        app/*@START_MENU_TOKEN@*/.keys["more"]/*[[".keyboards",".keys[\"more, letters\"]",".keys[\"more\"]"],[[[-1,2],[-1,1],[-1,0,1]],[[-1,2],[-1,1]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.keys["2"].tap()
        app.keys["5"].tap()
        app.buttons["Return"].tap()
        
        app.textFields["№"].tap()
        app/*@START_MENU_TOKEN@*/.keys["more"]/*[[".keyboards",".keys[\"more, letters\"]",".keys[\"more\"]"],[[[-1,2],[-1,1],[-1,0,1]],[[-1,2],[-1,1]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.keys["2"].tap()
        app.buttons["Return"].tap()
        
        //13
        app.buttons["teamButton"].tap()
        app.pickerWheels.element.adjust(toPickerWheelValue: "FC Barcelona")
       
        app.buttons["positionButton"].tap()
        app.pickerWheels.element.adjust(toPickerWheelValue: "Forward")
        
        //14
        app.buttons["Save"].tap()
        app.buttons["In Play"].tap()
        sleep(2)
    }
    
    //15
    func testPlayerSearh() {
        app.launch()
        app.navigationBars["Team Manager"].buttons["Search"].tap()
        
        app.textFields["Name"].tap()
        app/*@START_MENU_TOKEN@*/.buttons["shift"]/*[[".keyboards.buttons[\"shift\"]",".buttons[\"shift\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        for i in "Sergio" {
            app.keys["\(i)"].tap()
        }
        app.buttons["Return"].tap()
        app.buttons["Start"].tap()
        
        sleep(2)
        app.navigationBars["Team Manager"].buttons["Search"].tap()
        app.buttons["Reset"].tap()
        
        sleep(2)
        app.navigationBars["Team Manager"].buttons["Search"].tap()
        app.textFields["Age"].tap()
        app/*@START_MENU_TOKEN@*/.keys["more"]/*[[".keyboards",".keys[\"more, letters\"]",".keys[\"more\"]"],[[[-1,2],[-1,1],[-1,0,1]],[[-1,2],[-1,1]]],[0]]@END_MENU_TOKEN@*/.tap()
        app.keys["2"].tap()
        app.keys["5"].tap()
        app.buttons["Return"].tap()
        app.buttons["<="].tap()
        app.buttons["Start"].tap()
    
        sleep(2)
        app.navigationBars["Team Manager"].buttons["Search"].tap()
        app.buttons["Reset"].tap()
        
        sleep(2)
        app.navigationBars["Team Manager"].buttons["Search"].tap()
        app.buttons["teamButton"].tap()
        app.pickerWheels.element.adjust(toPickerWheelValue: "FC Barcelona")
        app.buttons["positionButton"].tap()
        app.pickerWheels.element.adjust(toPickerWheelValue: "Defender")
        app.buttons["Start"].tap()
        sleep(2)
        
    }
    
    //16
    func testDeleteElement() {
        app.launch()
        
        //17
        let table = app.tables["playerTableView"]
        
        //18
        let cell = table.cells.containing(.cell, identifier: "PlayerTableViewCell").containing(.staticText, identifier: "David de Gea").element
        
        table.swipeToElement(element: cell)
        
        //19
        cell.swipeLeft()
        app.buttons["DELETE"].tap()
    }
}
//20
extension XCUIElement {
    func swipeToElement(element: XCUIElement) {
        while !element.isHittable {
            swipeUp()
        }
    }
}
