//
//  UnitTestTests.swift
//  UnitTestTests
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import XCTest
//3
@testable import UnitTest

class UnitTestTests: XCTestCase {
    //4
    var bruteForceToTest: BruteForce!
    let input = "1X2r"
    //5
    override func setUp() {
        super.setUp()
        bruteForceToTest = BruteForce()
    }
    //6
    override func tearDown() {
        super.tearDown()
        bruteForceToTest = nil
    }
    //7
    func testMainQueuBruteForce() {
        let output = bruteForceToTest.startMainQueue(password: input)!
        XCTAssertEqual(input, output)
        
    }
    //8
    func test2QueuBruteForce() {
        var output = ""
        
        bruteForceToTest.start2Queue(password: input) {
            result in
            output = result!
        }
        
        XCTAssertEqual(input, output)
    }
    //9
    func test4QueuBruteForce() {
        var output = ""
        //10
        let expectation = self.expectation(description: "brute")
        
        bruteForceToTest.start4Queue(password: input) {
            result in
            output = result!
            //11
            expectation.fulfill()
        }
        //12
        waitForExpectations(timeout: 20, handler: nil)
        XCTAssertEqual(input, output)
    }
    //13
    func testPerformance() {
        self.measure {
            let input = "aaaa"
            let output = bruteForceToTest.startMainQueue(password: input)!
            XCTAssertEqual(input, output)
        }
    }
}
