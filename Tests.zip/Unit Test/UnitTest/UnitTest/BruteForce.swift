//
//  BruteForce.swift
//  UnitTest
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import Foundation

class BruteForce {
    let characterArray = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
   
    private var passwordIsBruted = false
    
    // MARK: Public
    //2
    func startMainQueue(password: String) ->String? {
        
        let result = self.bruteForce(startString: "0000", endString: "ZZZZ", password: password)
        return result
    }
    
    func start2Queue(password: String, completion: @escaping (_ password: String?)->()) {
        
        DispatchQueue.global().async {
            let result = self.bruteForce(startString: "0000", endString: "tttt", password: password)
            if result != nil {
                completion(result)
            }
        }
        DispatchQueue.global().async {
            let result = self.bruteForce(startString: "uuuu", endString: "ZZZZ", password: password)
            if result != nil {
                completion(result)
            }
        }
    }
    
    func start4Queue(password: String, completion: @escaping (_ password: String?)->()) {
        
        DispatchQueue.global().async {
            let result = self.bruteForce(startString: "0000", endString: "eeee", password: password)
            if result != nil {
                completion(result)
            }
        }
        DispatchQueue.global().async {
            let result = self.bruteForce(startString: "ffff", endString: "tttt", password: password)
            if result != nil {
                completion(result)
            }
        }
        
        DispatchQueue.global().async {
            let result = self.bruteForce(startString: "uuuu", endString: "JJJJ", password: password)
            if result != nil {
                completion(result)
            }
        }
        DispatchQueue.global().async {
            let result = self.bruteForce(startString: "KKKK", endString: "ZZZZ", password: password)
            if result != nil {
                completion(result)
            }
        }
    }
    
    // MARK: Private
    
    // 1
    private func bruteForce(startString: String, endString: String, password: String) -> String? {
        let inputPassword = password
        var startIndexArray = [Int]()
        var endIndexArray = [Int]()
        let maxIndexArray = characterArray.count
        
        // Создает массивы индексов из входных строк
        for char in startString {
            for (index, value) in characterArray.enumerated() where value == "\(char)" {
                startIndexArray.append(index)
            }
        }
        for char in endString {
            for (index, value) in characterArray.enumerated() where value == "\(char)" {
                endIndexArray.append(index)
            }
        }
        
        var currentIndexArray = startIndexArray
        
        // Цикл подбора пароля
        while true || passwordIsBruted {
            
            // Формируем строку проверки пароля из элементов массива символов
            let currentPass = self.characterArray[currentIndexArray[0]] + self.characterArray[currentIndexArray[1]] + self.characterArray[currentIndexArray[2]] + self.characterArray[currentIndexArray[3]]
            
            // Выходим из цикла если пароль найден, или, если дошли до конца массива индексов
            if inputPassword == currentPass  {
                passwordIsBruted = true
                return currentPass
            } else {
                if currentIndexArray.elementsEqual(endIndexArray) {
                    break
                }
                
                // Если пароль не найден, то происходит увеличение индекса. Для этого в цикле, начиная с последнего элемента осуществляется проверка текущего значения. Если оно меньше максимального значения (61), то индекс просто увеличивается на 1.
                //Например было [0, 0, 0, 5] а станет [0, 0, 0, 6]. Если же мы уже проверили последний индекс, например [0, 0, 0, 61], то нужно сбросить его в 0, а "старший" индекс увеличить на 1. При этом далее в цикле проверяется переполение "старшего" индекса тем же алгоритмом.
                //Таким образом [0, 0, 0, 61] станет [0, 0, 1, 0]. И поиск продолжится дальше:  [0, 0, 1, 1],  [0, 0, 1, 2],  [0, 0, 1, 3] и т.д.
                for index in (0 ..< currentIndexArray.count).reversed() {
                    guard currentIndexArray[index] < maxIndexArray - 1 else {
                        currentIndexArray[index] = 0
                        continue
                    }
                    currentIndexArray[index] += 1
                    break
                }
            }
        }
        return nil
    }
}
